<script src="assets/js/sweetalert2.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/fontawesome.min.js"></script>
<script src="assets/js/axios.min.js"></script>
<script src="assets/js/app.js"></script>

</body>
</html>