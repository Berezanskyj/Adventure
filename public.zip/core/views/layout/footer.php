<footer>
    <div class="logo-footer">
        <img src="assets/images/header-logo.png" alt="Adventure Logo">
    </div>
    <div class="texto-footer">
        <p>© 2024 Adventure, Inc. All rights reserved.</p>
    </div>
</footer>