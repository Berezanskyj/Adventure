<?php

$total_produtos = 0;

if (isset($_SESSION['carrinho'])) {
    foreach ($_SESSION['carrinho'] as $quantidade) {
        $total_produtos += $quantidade;
    }
}

$totalPreco = 0; // Inicializa a variável para o preço total
$index = 0;
$total_rows = count($carrinho);

foreach ($carrinho as $produto) {
    if ($index < $total_rows - 1) {
        $totalPreco += $produto['precoTotal']; // Soma o subtotal de cada produto
        $index++;
    }

}

?>


<a href="?a=limpar_carrinho">Limpar Carrinho</a>

<link rel="stylesheet" href="assets/css/carrinho.css">

<div class="container">
        <h1>Seu Carrinho</h1>
        <table class="cart-table">
            <thead>
                <tr>
                    <th class="col">Imagem</th>
                    <th class="col">Produto</th>
                    <th class="col">Quantidade</th>
                    <th class="col">Preço Unitário</th>
                    <th class="col">Subtotal</th>
                    <th class="col">Ação</th>
                    <th class="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $index = 0;
                $total_rows = count($carrinho);
                ?>
                <?php foreach ($carrinho as $produto): ?>
                    <?php if ($index < $total_rows -1): ?>
                    <tr>
                        <!-- Lista dos produtos -->
                        <td class="hover"><img src="assets/images/produtos/<?= $produto['imagem']?>" width="150px"></td>
                        <td class="hover"><?= $produto['nome'] ?></td>
                        <td class="hover"><?= $produto['quantidade'] ?></td>
                        <td class="hover">R$ <?= str_replace('.', ',', $produto['preco'] ) ?></td>
                        <td class="hover">R$ <?= str_replace('.', ',', $produto['precoTotal'])?></td>
                        <td class="hover"><button class="btn-remover">Remover</button></td>
                    </tr>
                    <?php endif; ?>
                    <?php $index++;?>
                <?php endforeach; ?>
                    

            </tbody>
        </table>

        <div class="cart-summary">
            <h2>Resumo do Pedido</h2>
            <div class="summary-details">
                <p>Total de Itens: <span id="carrinho">Itens: <?= $total_produtos ?></span></p>
                
                <p>Total a Pagar: <span>R$ <?= str_replace('.', ',', $totalPreco) ?></span></p>
            </div>
            <button class="btn-finalizar">Finalizar Compra</button>
        </div>
    </div>