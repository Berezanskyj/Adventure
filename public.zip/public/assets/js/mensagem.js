Swal.fire({
    title: "Parabéns!",
    text: "Você confirmou seu e-mail, já pode realizar seu login!",
    icon: "success"
});